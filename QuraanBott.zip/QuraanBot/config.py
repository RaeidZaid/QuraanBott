API_ID: int = 9010583
API_HASH: str = "e5f7c64179a467fdd7e08b1f84897045"
BOT_TOKEN: str = (
    "6716141167:AAH6ZFzddjpneCELzv7Fty8ogsaxLRZhP5c"  # ▶️GET IT FROM @BotFather ON TELEGRAM ◀
)
db_path: str = "source/database/db.json"  # ⚠ DON'T CHANGE THIS ⚠
owner_id: int = 1705301173 # YOUR TELEGRAM ID
version_date: str = "الثامن من مارس لعام 2024 في تمام الساعة 20:00"
